# Post-process htlatex output

For personal use only, will not work without major modifications.
