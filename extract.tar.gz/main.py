#!/bin/python
# pylint: disable=C0103

"""Post-process htlatex output"""

import shutil
import os
import utils
import figures

# root dir of latex project
path = '/home/stefan/Documents/bewerbungen/mfund'
tmpdir = '.tmp'
if os.path.isdir(tmpdir):
    shutil.rmtree(tmpdir)
os.mkdir(tmpdir)
# latex output directory
os.mkdir(tmpdir+'/nobackup')
cp = utils.Copier(path, tmpdir)
cp.copy('main.tex')
cp.copy('paper.bib')
cp.copy('model2-names.bst')
cp.copytree('figures')

figures.pdf2pngQuirk(tmpdir)
cmd = 'cd ' + tmpdir + '; latex -synctex=1 -output-directory=nobackup' \
        + ' -interaction=nonstopmode main_mod.tex'
print(cmd)
os.system(cmd)

cmd = 'cd ' + tmpdir + '; bibtex nobackup/main_mod.aux'
print(cmd)
os.system(cmd)

shutil.copyfile(tmpdir + '/nobackup/main_mod.bbl', tmpdir + '/main_mod.bbl')

cmd = 'cd ' + tmpdir + '; htlatex main_mod.tex "xhtml, charset=utf-8" " -cunihtf -utf8"'
print(cmd)
os.system(cmd)

# necessary to run twice for bibliography?
cmd = 'cd ' + tmpdir + '; htlatex main_mod.tex "xhtml, charset=utf-8" " -cunihtf -utf8"'
print(cmd)
os.system(cmd)

figures.png2svgQuirk(tmpdir)

