#!/bin/python
# pylint: disable=C0103

"""Check that there is an *.svg for each *.pdf. Insert a (temporary)
   dummy *.png for *.pdf in tex file, to play nice with htlatex."""

import os
import glob
import shutil

def pdf2pngQuirk(path):
    """Check that there is an *.svg for each *.pdf. Insert a (temporary)
   dummy *.png for *.pdf in tex file, to play nice with htlatex."""
    listing = glob.glob(path+'/figures/*.pdf')
    for fname in listing:
        svgname = fname.replace('.pdf', '.svg')
        if not os.path.isfile(svgname):
            raise Exception('There is no file \"' + os.path.basename(svgname) + '\"')
        # create a dummy *.png file
        shutil.copyfile('dummy.png', fname.replace('.pdf', '.png'))

    with open(path + "/main.tex", 'r') as fin:
        with open(path + "/main_mod.tex", 'w') as fout:
            for line in fin:
                if '\\includegraphics' in line:
                    fout.write(line.replace('.pdf', '.png'))
                    continue
                fout.write(line)

def png2svgQuirk(path):
    """Replace dummy *.png with *.svg"""
    with open(path + "/main_mod.html", 'r') as fin:
        with open(path + "/main.html", 'w') as fout:
            for line in fin:
                # TODO: should instead search for img tags, but htlatex makes 
                # linebreaks...
                if 'src=' in line:
                    fout.write(line.replace('.png', '.svg'))
                    continue
                fout.write(line)
                